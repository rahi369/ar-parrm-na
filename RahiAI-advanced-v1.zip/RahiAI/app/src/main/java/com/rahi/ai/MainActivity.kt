package com.rahi.ai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.widget.*
import android.text.InputType
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private val executor = Executors.newSingleThreadExecutor()
    private val memory = mutableListOf<String>()
    private val history = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        chat = findViewById(R.id.chat)
        input = findViewById(R.id.input)
        status = findViewById(R.id.status)
        prefs = getSharedPreferences("rahi_ai", Context.MODE_PRIVATE)
        loadMemory()
        refreshStatus()
        append("Rahi AI", "হাই Rahi! 🤖 আমি প্রস্তুত। Online থাকলে cloud AI ব্যবহার করব, আর offline হলে local assistant mode-এ কাজ করব।")

        findViewById<Button>(R.id.sendButton).setOnClickListener { send() }
        findViewById<Button>(R.id.micButton).setOnClickListener { startVoice() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { settings() }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        append("তুমি", text)
        if (handleLocalCommand(text)) return
        if (isOnline()) onlineReply(text) else offlineReply(text)
    }

    private fun handleLocalCommand(text: String): Boolean {
        val lower = text.lowercase(Locale.getDefault())
        if (lower.startsWith("মনে রাখ") || lower.startsWith("remember")) {
            val value = text.substringAfter(" ", "").trim()
            if (value.isNotEmpty()) {
                memory.add(value)
                saveMemory()
                append("Rahi AI", "মনে রাখলাম: $value 🧠")
            }
            return true
        }
        if (lower.contains("কি কি মনে") || lower.contains("what do you remember")) {
            append("Rahi AI", if (memory.isEmpty()) "এখনো কোনো personal memory নেই।" else memory.joinToString("\n• ", prefix = "আমি যা মনে রেখেছি:\n• "))
            return true
        }
        if (lower.startsWith("open ") || lower.startsWith("ওয়েবসাইট খোল")) {
            val url = text.substringAfter(" ").trim().let { if (it.startsWith("http")) it else "https://$it" }
            try { startActivity(Intent(Intent.ACTION_VIEW, UriCompat.parse(url))) } catch (_: Exception) {}
            append("Rahi AI", "Browser খোলার চেষ্টা করেছি।")
            return true
        }
        return false
    }

    private fun onlineReply(userText: String) {
        status.text = "ONLINE • thinking"
        val endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions")!!
        val key = prefs.getString("api_key", "")!!
        val model = prefs.getString("model", "gpt-4o-mini")!!
        if (key.isBlank()) {
            status.text = "ONLINE • setup needed"
            append("Rahi AI", "Internet আছে, কিন্তু API key সেট করা হয়নি। ⚙️ Settings থেকে endpoint, key এবং model সেট করো।")
            return
        }
        executor.execute {
            try {
                val conn = URL(endpoint).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.doOutput = true
                val messages = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "You are Rahi AI, a helpful personal assistant. Be concise, honest, and safety-conscious. Personal memories: ${memory.joinToString(" | ")}"))
                    .put(JSONObject().put("role", "user").put("content", userText))
                val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.7)
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}: $response")
                val root = JSONObject(response)
                val answer = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                    ?: "উত্তর পাওয়া যায়নি।"
                runOnUiThread { status.text = "ONLINE"; append("Rahi AI", answer) }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "ONLINE • error"
                    append("Rahi AI", "Online AI-তে সমস্যা হয়েছে, তাই offline mode-এ fallback করছি।\n\n${e.message ?: "Unknown error"}")
                    offlineReply(userText)
                }
            }
        }
    }

    private fun offlineReply(text: String) {
        status.text = "OFFLINE"
        val lower = text.lowercase(Locale.getDefault())
        val answer = when {
            lower.contains("website") || lower.contains("ওয়েব") -> "Offline-এ আমি website project-এর plan, file structure ও code template তৈরি করতে সাহায্য করতে পারি। Live deployment-এর জন্য Internet লাগবে।"
            lower.contains("hsc") || lower.contains("পড়") -> "HSC-এর জন্য কাজটা ছোট অংশে ভাগ করো। চাইলে আমি chapter-wise study task সাজিয়ে দিতে পারি। 📚"
            lower.contains("samia") -> "Samia’s Closet-এর project-related তথ্য memory-তে রাখতে পারি। যেমন: product, offer, owner info বা website requirement।"
            else -> "আমি এখন offline assistant mode-এ আছি। তুমি আমাকে কোনো note মনে রাখতে, plan বানাতে, local command দিতে বা project-এর code নিয়ে সাহায্য করতে বলতে পারো।\n\nনোট: সত্যিকারের generative offline AI চালাতে এই project-এ একটি compatible local model runtime + model file যোগ করতে হবে।"
        }
        append("Rahi AI", answer)
    }

    private fun refreshStatus() { status.text = if (isOnline()) "ONLINE" else "OFFLINE" }

    private fun isOnline(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val n = cm.activeNetwork ?: return false
        val c = cm.getNetworkCapabilities(n) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { append("Rahi AI", "এই ফোনে speech recognition service পাওয়া যায়নি।"); return }
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 91); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Rahi AI-কে বলো…")
        }
        startActivityForResult(intent, 92)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 92 && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            input.setText(results?.firstOrNull() ?: "")
            input.requestFocus()
        }
    }

    private fun settings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 10, 30, 0) }
        val endpoint = EditText(this).apply { hint = "API endpoint"; setText(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions")) }
        val key = EditText(this).apply { hint = "API key"; setText(prefs.getString("api_key", "")); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val model = EditText(this).apply { hint = "Model name"; setText(prefs.getString("model", "gpt-4o-mini")) }
        box.addView(endpoint); box.addView(key); box.addView(model)
        AlertDialogCompat.show(this, "Rahi AI Settings", box) {
            prefs.edit().putString("endpoint", endpoint.text.toString().trim()).putString("api_key", key.text.toString().trim()).putString("model", model.text.toString().trim()).apply()
            refreshStatus()
        }
    }

    private fun append(who: String, text: String) {
        chat.append("\n$who\n$text\n")
    }

    private fun loadMemory() {
        val raw = prefs.getStringSet("memory", emptySet()) ?: emptySet()
        memory.addAll(raw)
    }
    private fun saveMemory() { prefs.edit().putStringSet("memory", memory.toSet()).apply() }
}

object UriCompat { fun parse(s: String): android.net.Uri = android.net.Uri.parse(s) }

object AlertDialogCompat {
    fun show(ctx: Context, title: String, view: View, save: () -> Unit) {
        android.app.AlertDialog.Builder(ctx).setTitle(title).setView(view).setPositiveButton("Save") { _, _ -> save() }.setNegativeButton("Cancel", null).show()
    }
}
