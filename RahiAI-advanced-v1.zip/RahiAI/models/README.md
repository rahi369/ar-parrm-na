# Offline model slot

The project currently contains an honest offline fallback instead of pretending a model exists.

For true offline generative AI, add a small quantized model and an on-device runtime that supports the target Android ABI/device. The integration point should be an interface similar to:

```kotlin
interface LocalModelEngine {
    fun isReady(): Boolean
    fun generate(systemPrompt: String, userText: String, memory: List<String>): String
}
```

Then replace `offlineReply()` in `MainActivity.kt` with a call to the local engine.

Because the phone has 4 GB physical RAM, choose a small model and keep context length modest. Extended/virtual RAM is not equivalent to physical RAM.
